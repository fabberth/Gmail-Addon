const express = require('express');
const app = express();
require('dotenv').config();
const morgan = require('morgan');
const axios = require('axios');
const fs = require('fs');
const bodyParser = require('body-parser');
const xml2js = require('xml2js');
const EmlParser = require('eml-parser');
const { base64encode } = require('nodejs-base64');
const https = require('https');
const sql = require('mssql')
var parserXml = require('xml2json');


//setting---------------------------------------------------------------------------------------------------------------------------------
app.set('port', process.env.PORT || 3001);

//middlewares-----------------------------------------------------------------------------------------------------------------------------
app.use(morgan('dev'));
app.use(express.static(__dirname +'/login'));
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));


//ANALIZA SI LA CUENTA GOOGLE ES NUEVA-----------------------------------------------------------------------------------------------------
async function conexion () {
  try {
      // make sure that any items are correctly URL encoded in the connection string
      //await sql.connect("Server=DESKTOP-L0VB48E;User Id=glsbox;Password=glsbox;Min Pool Size=2;Database=addon;trustServerCertificate=true;")
      await sql.connect(`Server=${process.env.SERVER};User Id=${process.env.USERID};Password=${process.env.PASSWORD};Min Pool Size=2;Database=addon;trustServerCertificate=true;`)
      return true
  } catch (err) {
      console.log(err)
      return false
  }
}


//GUARDAR---------------------------------------------------------------------------------------------------------------------------------------
//Guarda los datos en un json (de momento)
async function guardar (usuarioGoogle,token,urlAbox,urlSoap,usuario,documentTypeCode){

  let ini = 0;

  var dabaBase = await conexion();
  if (dabaBase == true){

    const result = await sql.query(`UPDATE GmailAccounts SET token='${token}',urlAbox='${urlAbox}',urlSoap='${urlSoap}',usuario='${usuario}',documentTypeCode='${documentTypeCode}' WHERE usuarioGoogle='${usuarioGoogle}';`)
    //console.log(result.rowsAffected)

    if (result.rowsAffected[0]==1){

        console.log('se actualizo: '+usuarioGoogle)
        ini = 1;
        sql.close()
        return ini
        

    } else{

      //console.log('no se encontro el usuario')
      sql.close()
      return ("No se encontro usuario "+usuarioGoogle)
      
    }

  }else{

      console.log("error en actualizar")
      return ("error en actualizar")

  }
  
  
}


//BORRAR--------------------------------------------------------------------------------------------------------------------------------------------
//Borra los datos del json, se elimina el campo del token
async function borrar (usuarioGoogle){

  var dabaBase = await conexion();
  if (dabaBase == true){

    const result = await sql.query(`UPDATE GmailAccounts SET token=NULL WHERE usuarioGoogle='${usuarioGoogle}';`)
    //console.log(result.rowsAffected)

    if (result.rowsAffected[0]==1){

        console.log('se cerro sesion: '+usuarioGoogle)
        sql.close()
        return "cerro sesion"
        

    } else{

      //console.log('no se encontro el usuario')
      sql.close()
      return "no se encontro usuario"
      
    }

  }else{

      //console.log("error en cerrar sesion")
      return ("error en cerrar sesion")

  }

}


//BUSCAR----------------------------------------------------------------------------------------------------------------------------------------------
//esta funcion busca el campo urlSoap del json y lo retorna
async function getDatos(usuarioGoogle){

  var dabaBase = await conexion();
  
  if (dabaBase == true){

    const result = await sql.query(`SELECT * FROM GmailAccounts WHERE usuarioGoogle ='${usuarioGoogle}' ;`)

    let json = {
      accounId:result.recordset[0].accounId,
      token:result.recordset[0].token,
      urlAbox:result.recordset[0].urlAbox,
      urlSoap:result.recordset[0].urlSoap,
      usuario:result.recordset[0].usuario,
      documentTypeCode:result.recordset[0].documentTypeCode
    }

    sql.close()

    return json

  }

}


//PRIMERA CONSULTA----------------------------------------------------------------------------------------------------------------------------
//Gmail consulta si el correo tiene token. si tiene token retorna true, de lo contrario retorna false 



app.post(/consulta/,async(req, res)=>{

  const usuarioGoogle = req.body.usuarioGoogle;
  console.log(usuarioGoogle);
  var estado = false;

  var dabaBase = await conexion();
  
  if (dabaBase == true){

      const result = await sql.query(`SELECT * FROM GmailAccounts WHERE usuarioGoogle ='${usuarioGoogle}' ;`)
      //console.log(result.rowsAffected.length)

        if (result.recordset.length==0){

          var inse = await sql.query(`INSERT INTO GmailAccounts (usuarioGoogle) VALUES ('${usuarioGoogle}');`)
          //console.log(inse);
          console.log('insertado: ',usuarioGoogle);
          sql.close()
          estado = 'primeraVez'
          console.log(estado);
          res.send(JSON.stringify({ tipoDocumental: [], estado:estado}))

        } else{
          //query donde consulte si el usuarioGoogle tiene token

          if (result.recordset[0].token != null){

            estado = true
            sql.close()
            console.log(estado);
            res.send(JSON.stringify({ tipoDocumental: result.recordset[0].documentTypeCode, estado:estado, tipoDefault:'100.04.03.El.E#'}))

          }else{
            if (result.recordset[0].urlSoap == null){

              estado = 'primeraVez'
              sql.close()
              console.log(estado);
              res.send(JSON.stringify({ tipoDocumental: [], estado:estado}))

            }else{

            sql.close()
            console.log(estado);
            res.send(JSON.stringify({ tipoDocumental: [], estado:estado}))
            }

          }
          
        }

  } else{

    console.log('conexion a la base de datos fracaso');

    res.send('conexion a la base de datos fracaso')

  }

});


//URL SOAP ------------------------------------------------------------------------------------------------------------------------------------
//Verifica si la url de abox ingresada tiene la api de document

app.post(/servicioSoap/,(req,res)=>{

  var url = req.body.urlSoap
  //console.log(url)
    var xml =`<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
                <Body>
                    <GetServerInfo xmlns="http://tempuri.org/"/>
                </Body>
              </Envelope>`

    axios.post(url,xml,
      {headers:
          {'Content-Type':'text/xml;charset=utf-8',
          'Accept-Encoding': 'gzip,deflate',
          'Content-Length':xml.length,
          'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/GetServerInfo"}
      })
      .then(function(resp){
        //console.log(resp.data)
        var info = "";
        var parser = new xml2js.Parser({explicitArray: false, trim: true});
        parser.parseString(resp.data, (err, respu) => {
          //console.log(respu)
          info = respu['s:Envelope']['s:Body'].GetServerInfoResponse.GetServerInfoResult['a:exitvalue'];

          res.send(JSON.stringify({
            mensaje: info
          }));

        })
      })
      .catch(function(err){

        //console.log("Url invalida");
        res.send(JSON.stringify({
          mensaje: "Url invalida"
        }));

      })
  
})

async function documenType(usuarioGmail,token,urlSoap){
  var xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
     <tem:FindAllEntityTypes>
        <tem:token>${token}</tem:token>
        <tem:entity>document</tem:entity>
     </tem:FindAllEntityTypes>
  </soapenv:Body>
</soapenv:Envelope>`

axios.post(urlSoap,xml,
  {headers:
      {'Content-Type':'text/xml;charset=utf-8',
      'Accept-Encoding': 'gzip,deflate',
      'Content-Length':xml.length,
      'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/FindAllEntityTypes"}
  })
  .then(function(resp){
    var parser = new xml2js.Parser({explicitArray: false, trim: true});
    parser.parseString(resp.data, async (err, respu) => {
      //console.log(respu);
      var string = respu['s:Envelope']['s:Body'].FindAllEntityTypesResponse.FindAllEntityTypesResult['a:exitvalue'];

      var json = parserXml.toJson(string);

      json=JSON.parse(json)

      let carga = []

      for (var i = 0; i < json.dsDocument.TiposDocumentales.length; i++){

        var date = {
          nombre:json.dsDocument.TiposDocumentales[i].nombre,
          tipo:json.dsDocument.TiposDocumentales[i].codigoTipo
        }

        carga.push(date)

      } 

      var dabaBase = await conexion();

      if (dabaBase == true ){
        var convert = JSON.stringify(carga)
        const result = await sql.query(`UPDATE GmailAccounts SET documentTypeCode='${convert}' WHERE usuarioGoogle='${usuarioGmail}';`)
        //console.log(result.rowsAffected)
    
        if (result.rowsAffected[0]==1){

            sql.close()

            return'guarda documenType Exito'

        }
      } else  {


        return'error al conectar base de dato'

      }

    })
  })
  .catch(function(err){
    console.log(err);
    return 'error al cargar documenType'
  })
}
//INICIO DE SESION --------------------------------------------------------------------------------------------------------------------
//Inicia sesion en abox mediante el servicio soap, antes de iniciar verefica si los datos son correctos para guardarlos en el json (de momento)


app.post(/inicioSesion/,async(req, res,)=>{
  var nombre = req.body.usuarioGmail;
  var usuario = req.body.usuario;
  var contraseña = req.body.contrasena;
  var urlAbox = req.body.urlAbox;
  var urlSoap = req.body.urlSoap;
  var documentTypeCode = req.body.documentTypeCode;  //console.log(urlSoap+" - "+ contraseña + " - "+nombre)

  var xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soapenv:Header/>
    <soapenv:Body>
       <tem:IniciaSesion>
          <!--Optional:-->
          <tem:usuario>${usuario}</tem:usuario>
          <!--Optional:-->
          <tem:clave>${contraseña}</tem:clave>
          <!--Optional:-->
          <tem:acceso>{Create}</tem:acceso>
          <!--Optional:-->
          <tem:rememberMe>false</tem:rememberMe>
          <!--Optional:-->
          <tem:deviceToLogin>Test</tem:deviceToLogin>
       </tem:IniciaSesion>
    </soapenv:Body>
 </soapenv:Envelope>`
  axios.post(urlSoap,xml,
    {headers:
      {'Content-Type':'text/xml;charset=utf-8',
      'Accept-Encoding': 'gzip,deflate',
      'Content-Length':xml.length,
      'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/IniciaSesion"}
    })
    .then(function (response) {
      //console.log(response.data);
      var parser = new xml2js.Parser({explicitArray: false, trim: true});

      parser.parseString(response.data, async (err, result) => {
        //console.log(result);
        var token = result['s:Envelope']['s:Body'].IniciaSesionResponse.IniciaSesionResult['a:exitvalue']; //console.log(token)
        
        var errormsg = result['s:Envelope']['s:Body'].IniciaSesionResponse.IniciaSesionResult['a:errormsg']; //console.log(errormsg)

        if (token.length>10){

          var guarda = await guardar(nombre,token,urlAbox,urlSoap,usuario,documentTypeCode); //console.log(token +" - guarda: "+guarda);
          var document = await documenType(nombre,token,urlSoap);

          res.send(JSON.stringify({
            mensaje: guarda,
            token : token
          }));

        } else{

          res.send(JSON.stringify({
            mensaje: errormsg,
            token : token

        }));
        }
      });

    })
    .catch(function (error) {
      //console.log(error.response);
      console.log("error inicio sesion: "+nombre);
      res.send(JSON.stringify({
        mensaje: "error"
      }));

    });
});


//---------------------------------------------------------------------------------------------------------------------------------------------


async function GuardarToken(usuarioGoogle,token,usuario){

  let ini = 0;

  var dabaBase = await conexion();
  if (dabaBase == true){

    const result = await sql.query(`UPDATE GmailAccounts SET token='${token}',usuario='${usuario}' WHERE usuarioGoogle='${usuarioGoogle}';`)
    //console.log(result.rowsAffected)

    if (result.rowsAffected[0]==1){

        console.log('se actualizo: '+usuarioGoogle)
        ini = 1;
        sql.close()
        return ini
        

    } else{

      //console.log('no se encontro el usuario')
      sql.close()
      return ("No se encontro usuario "+usuarioGoogle)
      
    }

  }else{

      console.log("error en actualizar")
      return ("error en actualizar")

  }
  
  
}


app.post(/identificarse/,async(req, res,)=>{

  var usuarioGmail = req.body.usuarioGmail;
  var datos = await getDatos(usuarioGmail);
  var usuario = req.body.usuario;
  var contraseña = req.body.contrasena;

  var xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soapenv:Header/>
    <soapenv:Body>
       <tem:IniciaSesion>
          <!--Optional:-->
          <tem:usuario>${usuario}</tem:usuario>
          <!--Optional:-->
          <tem:clave>${contraseña}</tem:clave>
          <!--Optional:-->
          <tem:acceso>{Create}</tem:acceso>
          <!--Optional:-->
          <tem:rememberMe>false</tem:rememberMe>
          <!--Optional:-->
          <tem:deviceToLogin>Test</tem:deviceToLogin>
       </tem:IniciaSesion>
    </soapenv:Body>
 </soapenv:Envelope>`
  axios.post(datos.urlSoap,xml,
    {headers:
      {'Content-Type':'text/xml;charset=utf-8',
      'Accept-Encoding': 'gzip,deflate',
      'Content-Length':xml.length,
      'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/IniciaSesion"}
    })
    .then(function (response) {
      //console.log(response.data);
      var parser = new xml2js.Parser({explicitArray: false, trim: true});

      parser.parseString(response.data,async(err, result) => {
        //console.log(result);
        var token = result['s:Envelope']['s:Body'].IniciaSesionResponse.IniciaSesionResult['a:exitvalue']; //console.log(token)
        
        var errormsg = result['s:Envelope']['s:Body'].IniciaSesionResponse.IniciaSesionResult['a:errormsg']; //console.log(errormsg)

        if (token.length>10){


          var guardarToken = await GuardarToken(usuarioGmail,token,usuario); //console.log(token +" - guarda: "+guarda);
          documenType(usuarioGmail,token,datos.urlSoap)

          res.send(JSON.stringify({
            mensaje: guardarToken,
            token : token
          }));

        } else{
          //console.log(errormsg,token);
          //console.log(errormsg);
          res.send(JSON.stringify({
            mensaje: errormsg,
            token : token
        }));
        }
      });

    })
    .catch(function (error) {
      //console.log(error.response);
      console.log("error inicio sesion: "+usuarioGmail);
      res.send(JSON.stringify({
        mensaje: "error"
      }));

    });
});

//anexo----------------------------------------------------------------------------------------------------------------------------------------------------
//Carga el zip como anexo segundario del documento
function anexo (token,codigo,nArchivo,adjunto,urlSoa){
  var token2 = token
  var codigo2 = codigo
  var nArchivo2 = nArchivo
  var adjunto2 = adjunto
  let carga = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
     <tem:AnexarArchivo>
        <!--Optional:-->
        <tem:token>${token2}</tem:token>
        <!--Optional:-->
        <tem:codigo>${codigo2}</tem:codigo>
        <!--Optional:-->
        <tem:nombre>${nArchivo2}</tem:nombre>
        <!--Optional:-->
        <tem:descripcion></tem:descripcion>
        <!--Optional:-->
        <tem:bytearray_archivo>${adjunto2}</tem:bytearray_archivo>
     </tem:AnexarArchivo>
  </soapenv:Body>
</soapenv:Envelope>`;
  axios.post(urlSoa,
            carga,
            {headers:
              {'Content-Type':'text/xml;charset=utf-8',
              'Accept-Encoding': 'gzip,deflate',
              'Content-Length':carga.length,
              'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/AnexarArchivo"}
            })
            .then(function (response) {
              //console.log(response.data);
              return true
            })
            .catch(function (error) {
              console.log(error)
              console.log('error al cargar el archivo')
              //console.log(error);
              return false
            });

}

//CREAR DOCUMENTOS EN ABOX ---------------------------------------------------------------------------------------------------------
/*
  Crea el documento en abox usando el la api document
  - carga en el anexo principal del documento un eml del correo original
  - cargar los demas datos en del correo en los metadatos
  */
function sliceText(text) {
  var inicio = text.search("<")+1;
  var fin = text.search(">");
  var newText = text.slice(inicio,fin);
  return newText;
}



async function getattachments(cuerpo){

  var emlCorreo = new EmlParser(cuerpo)

  var result = await emlCorreo.parseEml();

    var dataAdjunto = [];

    var  datos = result.attachments
    
    for(var i = 0; i < datos.length; i++){

      var nameAdjunto = datos[i].filename;
      var base64 =  datos[i].content;

      var jsson = {
        nombre:nameAdjunto,
        bytes:base64
      }

      dataAdjunto.push(jsson);
    }
  return dataAdjunto
}

app.post(/crearDocumento/,async(req, res)=>{

  var usuarioGoogle = req.body.usuarioGoogle;

  var asunto = req.body.asunto;

  var document = req.body.document;

  var cuerpo = req.body.APrincipal;
  var eml = base64encode(cuerpo);

  var bodyCorreo = req.body.bodyCorreo;
  bodyCorreo=bodyCorreo.replace(/[^a-zA-Z0-9]/g," ");

  var idMessage = req.body.idMessage;

  var mailFrom = req.body.mailFrom;
  mailFrom = sliceText(mailFrom);

  var mailCC = req.body.mailCC;
  mailCC = mailCC.replace(/<|>/g,"");

  var mailDate = req.body.mailDate;
  var a = new Date(mailDate);
  var mes = a.getMonth()+1
  var fecha = a.getDate() +"/"+mes +"/"+a.getFullYear()

  var mailTo = req.body.mailTo;
  mailTo = mailTo.replace(/<|>/g,"");
  
  var mailContentType = req.body.mailContentType;

  var mailMimeVersion = req.body.mailMimeVersion;

  var mailSize = req.body.mailSize;

  var checkAdjuntos = req.body.checkAdjuntos;

  var adjunto = ""
  if (checkAdjuntos=='true'){
    adjunto = await getattachments(cuerpo)
  }

  

  var datos = await getDatos(usuarioGoogle);

  var token = datos.token;


  var urlSoa = datos.urlSoap;

  let xmls = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
  <soapenv:Header/>
  <soapenv:Body>
     <tem:CreateDocument>
        <!--Optional:-->
         <tem:token>${token}</tem:token>
        <!--Optional:-->
        <tem:title>${asunto}</tem:title>
        <!--Optional:-->
        <tem:code></tem:code>
        <!--Optional:-->
        <tem:documentTypeCode>${document}</tem:documentTypeCode>
        <!--Optional:-->
        <tem:folderCode></tem:folderCode>
        <!--Optional:-->
        <tem:description>${bodyCorreo}</tem:description>
        <!--Optional:-->
        <tem:keywords></tem:keywords>
        <!--Optional:-->
        <tem:filename>${usuarioGoogle}.eml</tem:filename>
        <!--Optional:-->
        <tem:fileDescription></tem:fileDescription>
        <!--Optional:-->
        <tem:fileBytearray>${eml}</tem:fileBytearray>
        <!--Optional:-->
        <tem:metadataValues><![CDATA[<?xml version="1.0" encoding="UTF-8"?>
         <metadataValues>
         <metadataValue code="mailFrom">${mailFrom}</metadataValue>
         <metadataValue code="mailData.853">${mailTo}</metadataValue>
         <metadataValue code="mailData.854">${mailCC}</metadataValue>
         <metadataValue code="mailDate">${fecha}</metadataValue>
         <metadataValue code="mailSize">${mailSize}</metadataValue>
         <metadataValue code="mailAllHeaders">${asunto}</metadataValue>
         <metadataValue code="mailMessageId">${idMessage}</metadataValue>
         <metadataValue code="mailContentType">${mailContentType}</metadataValue>
         <metadataValue code="mailMimeVersion">${mailMimeVersion}</metadataValue>
         <metadataValue code="mailSourceFolder">${usuarioGoogle}</metadataValue>       
         </metadataValues>]]>
</tem:metadataValues>
     </tem:CreateDocument>
  </soapenv:Body>
</soapenv:Envelope>`;
  axios({
  method: 'post',
  url: urlSoa,
    data: xmls,
    headers: {  'Content-Type':'text/xml;charset=utf-8',
                'Accept-Encoding': 'gzip,deflate',
                'Content-Length':xmls.length,
                'SOAPAction':"http://tempuri.org/ILegacyDocumentApi/CreateDocument"
          },
      maxContentLength: 100000000, 
      maxBodyLength : 100000000})
           .then(resp=>{

            var idDocumento = "";
            var msgerror = "";
            var codigo = "";

            var parser = new xml2js.Parser({explicitArray: false, trim: true});
            parser.parseString(resp.data, (err, result) => {

               msgerror = result['s:Envelope']['s:Body'].CreateDocumentResponse.CreateDocumentResult['a:errormsg'];
               idDocumento = result['s:Envelope']['s:Body'].CreateDocumentResponse.CreateDocumentResult['a:guidvalue'];
               codigo = result['s:Envelope']['s:Body'].CreateDocumentResponse.CreateDocumentResult['a:exitvalue'];

            });

            if (checkAdjuntos == 'true' && msgerror == ""){
              
              for (var i = 0; i < adjunto.length; i++) {
                var nombre = adjunto[i].nombre;
                var base64 = adjunto[i].bytes.toString('base64');
                anexo (token,codigo,nombre,base64,urlSoa)
              }
            
            }
            if (msgerror == ""){
             //console.log(resp.data);
              var urlAbo = datos.urlAbox;
              res.send(JSON.stringify({
                exito: true,
                mensaje: urlAbo+`/Document/Documents/Show/${idDocumento}?version=1.0`
              }));

            } else {

                console.log("error al crear document: "+usuarioGoogle);
                res.send(JSON.stringify({
                  exito: false,
                  mensaje : msgerror
              }));

                if (msgerror == "No está autorizado o la sesión ha caducado."){
                  //borrar(usuarioGoogle)
                  console.log('cerro sesion: '+usuarioGoogle)
              }
            }
            })
           .catch(err=>{
              console.log(err);
              console.log("ERROR al crear documento: "+usuarioGoogle);
              res.send(JSON.stringify({
                exito: false,
                mensaje : "ERROR al crear documento"
              }));
            });
 });


//CERRAR SESION--------------------------------------------------------------------------------------------------------------------------
//Cierra la sesion borrando el token 
 app.post(/cerrarSesion/,async(req, res)=>{

    var usuarioGoogle = req.body.usuarioGoogle
    var msg = await borrar(usuarioGoogle);

    console.log('cerro sesion: '+usuarioGoogle);

    if (msg == "no se encontro usuario"){

      res.send("no se encontro usuario");

    }else{
      res.send(false);
    }
});


//HTML-------------------------------------------------------------------------------------------------------------------------------------
//responde con la pagina de inicio de sesion
const path = require('path')

app.get('/pagina/:file?', function (req, res) {

  console.log(req.query.correo);
  var index = fs.readFileSync(path.join(`${__dirname}/login/${req.params.file || 'index.html'}`),{encoding:'utf8', flag:'r'});
  index = index.replace('%%correo%%',req.query.correo)
	res.send(index);
});

app.get('/paginaIdenti/', function (req, res) {

  console.log(req.query.correo);
  var index = fs.readFileSync(path.join(`${__dirname}/login/${req.params.file || 'login.html'}`),{encoding:'utf8', flag:'r'});
  index = index.replace('%%correo%%',req.query.correo)
	res.send(index);

});



//server------------------------------------------------------------------------------------------------------------------------------------
/*https.createServer({
  cert: fs.readFileSync('src/cert_adptg.crt'),
  key: fs.readFileSync('src/llave_lista.key')
},app).listen(app.get('port'), () => {
    console.log (`Servidor https on port ${app.get('port')}`);
    //console.log(process.env.URLNODEJS);
});*/

app.listen(app.get('port'), () => {
  console.log (`Servidor on port ${app.get('port')}`);
});