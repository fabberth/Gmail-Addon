
//---------------------------------------------------------------------------------------------------------------------------------------------
var nodeJs = 'https://ddea-181-49-238-154.ngrok.io'


function identificarse(){
    var usuarioGmail = document.getElementById('usuarioGmail').value;
    var usuario = document.getElementById('usuario').value;
    var password = document.getElementById('contrasena').value;
    
    if (usuarioGmail.length>7 && usuario.length>2 && password.length>3){

        var contenedor = document.getElementById('contenedor_carga')
        contenedor.style.display = 'block';

        fetch (nodeJs+'/identificarse/',
            {
                headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify({
                    usuarioGmail: usuarioGmail,
                    usuario: usuario, 
                    contrasena: password,
                })
            }).then ( async msg => {
                var json = await msg.json()
                var mensaje = json.mensaje;
                contenedor.style.display = 'none';

                if (mensaje == 1){
                   
                    window.close();

                } else {
                    contenedor.style.display = 'none';
                    alert(mensaje)
                }
                
            })
            .catch(err => {
                contenedor.style.display = 'none';
                alert(err)
            })
    } else{
        alert("Por favor ingresar campos correctos")
    }

}


function atras(){

    var form = document.getElementById('form1')
    var form2 = document.getElementById('form02')
    form2.style.display = "none";
    form.style.display = "block";

}

//funcion que verifica los datos ingresados, llamando a el index.js
function verificar(){

    var form = document.getElementById('form1')
    var form2 = document.getElementById('form02')

    const soap = '/document-api.svc/soap'
    var urlAbox = document.getElementById('url').value;

    var contenedor = document.getElementById('contenedor_carga')

    

    var urlSoap = urlAbox+soap

    if (urlAbox == ""){

        alert("Por favor llenar tos los campos")

    } else{

        contenedor.style.display = 'block';

        fetch (nodeJs+'/servicioSoap/',
            {
                headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify({
                    urlSoap: urlSoap
                })
            })
            .then ( async msg => {
                var json = await msg.json()
                var mensaje = json.mensaje;
                if (mensaje == "Url invalida"){
                    contenedor.style.display = 'none';
                    document.getElementById('respuesta').innerHTML = mensaje
                } else{
                    contenedor.style.display = 'none';
                    //console.log(mensaje);
                    document.getElementById('respuesta').innerHTML = "Url valida"
                    form.style.display = "none";
                    form2.style.display = "block";
                    

                }
                
            })

    }
}


//-----------------------------------------------------------------------------------------------------------------------------------------------
//esta Funcion inicia sesion en abox, y crear la url de abox para utilizar la api document (SOAP). llamando el index.js
function login(){
    const soap = '/document-api.svc/soap'
    var urlAbox = document.getElementById('url').value;
    var documentTypeCode = "100.02.02.P.E#"
    var usuarioGmail = document.getElementById('usuarioGmail').value;
    var usuario = document.getElementById('usuario').value;
    var password = document.getElementById('contrasena').value;
    var urlSoap = urlAbox+soap

    var contenedor = document.getElementById('contenedor_carga')
    contenedor.style.display = 'block';
    
    if (usuarioGmail.length>7 && urlAbox.length>5 && documentTypeCode.length>3){
        fetch (nodeJs+'/inicioSesion/',
            {
                headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                },
                method: "POST",
                body: JSON.stringify({
                    usuarioGmail: usuarioGmail,
                    usuario: usuario, 
                    contrasena: password,
                    urlSoap: urlSoap,
                    urlAbox : urlAbox,
                    documentTypeCode : documentTypeCode

                })
            }).then ( async msg => {
                contenedor.style.display = 'none';
                var json = await msg.json()
                var mensaje = json.mensaje;

                if (mensaje == 1){

                    window.close();

                } else {
                    alert(mensaje)
                }
                
            })
            .catch(err => {
                contenedor.style.display = 'none';
                alert(err)
            })
    } else{
        alert("Por favor ingresar campos correctos")
    }
}