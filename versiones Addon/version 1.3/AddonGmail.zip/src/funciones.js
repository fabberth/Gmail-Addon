require('dotenv').config();
const sql = require('mssql');
const EmlParser = require('eml-parser');




/**

 * retorna true si esta conectado, false si fallo la conexion a la base de datos

 * @return  {boolean}

 */
let conexion = async function conexion ()
{
    try
    {
        await sql.connect(`Server=${process.env.SERVER};User Id=${process.env.USERID};Password=${process.env.PASSWORD};Min Pool Size=2;Database=addon;trustServerCertificate=true;`)
        return true
    } 
    catch (err) 
    {
        console.log(err)
        return false
    }
}



/**

 * funcion que guarda los datos en la base de datos

 * @return  {boolean}

 */

let guardar = async function guardar (usuarioGoogle,token,urlAbox,urlSoap,usuario)
{
  
    var dabaBase = await conexion();
    if (dabaBase == true)
    {
  
        const result = await sql.query(`UPDATE GmailAccounts SET token='${token}',urlAbox='${urlAbox}',urlSoap='${urlSoap}',usuario='${usuario}' WHERE usuarioGoogle='${usuarioGoogle}';`)
        //console.log(result.rowsAffected)

        if (result.rowsAffected[0]==1)
        {

            console.log('se actualizo: '+usuarioGoogle)

            sql.close()
            return true

        } 
        else
        {

        //console.log('no se encontro el usuario')
        sql.close()
        return ("No se encontro usuario "+usuarioGoogle)
        
        }
    }
    else
    {
  
        console.log("error en actualizar")
        return ("error en actualizar")
    }
    
}



/**

 * retorna todos los datos de ese usuario

 * @param  {string}

 * @return  {JSON}

 */

let getDatos = async function getDatos(usuarioGoogle)
{

    var dabaBase = await conexion();
    
    if (dabaBase == true)
    {
  
      const result = await sql.query(`SELECT * FROM GmailAccounts WHERE usuarioGoogle ='${usuarioGoogle}' ;`)
  
      let datos = {
        accounId:result.recordset[0].accounId,
        token:result.recordset[0].token,
        urlAbox:result.recordset[0].urlAbox,
        urlSoap:result.recordset[0].urlSoap,
        usuario:result.recordset[0].usuario,
        documentTypeCode:result.recordset[0].documentTypeCode
      }
  
      sql.close()
  
      return datos
  
    }
    else
    {
        return 'la conexion fallo'
    }
  
}



/**

 * borra el token de la base de datos retorna un string

 * @param  {string}

 * @return  {string}

 */

let borrar = async function borrar (usuarioGoogle)
{
    var dabaBase = await conexion();
    if (dabaBase == true)
    {
        const result = await sql.query(`UPDATE GmailAccounts SET token=NULL WHERE usuarioGoogle='${usuarioGoogle}';`)
        //console.log(result.rowsAffected)
  
        if (result.rowsAffected[0]==1){
    
            console.log('se cerro sesion: '+usuarioGoogle)
            sql.close()
            return "cerro sesion"
        } 
        else
        {
            //console.log('no se encontro el usuario')
            sql.close()
            return "no se encontro usuario"
        }
  
    }
    else
    {
        //console.log("error en cerrar sesion")
        return ("error en cerrar sesion")
  
    }
}


/**

 * guarda los tipos documentales del usuario

 * @param  {string}

 * @return  {string}

 */
let saveDocumenType = async function saveDocumenType(usuarioGmail,string)
{

    var json = await JSON.parse(string)

    let carga = []

    for (var i = 0; i < json.dsDocument.TiposDocumentales.length; i++)
    {
        var date = {
            nombre:json.dsDocument.TiposDocumentales[i].nombre,
            tipo:json.dsDocument.TiposDocumentales[i].codigoTipo
        }
        carga.push(date)
    }

    var dabaBase = await conexion();

    if (dabaBase == true )
    {

        var convert = JSON.stringify(carga)

        const result = await sql.query(`UPDATE GmailAccounts SET documentTypeCode='${convert}' WHERE usuarioGoogle='${usuarioGmail}';`)

        if (result.rowsAffected[0]==1)
        {

            sql.close()

            console.log('guardo Documentype database :',usuarioGmail)

            return 'guardo documentype'

        }
        else
        {
            console.log('No guardo Documentype database :',usuarioGmail);
            return 'No guardo Documentype database :',usuarioGmail
        }
    }
    else
    {
        return'error al conectar base de dato'
    }
    
  
}


/**

 * obtiene los attachments de un correo, y retorna un array con el nombre attachments y bytes attachments en base64

 * @param  {string}

 * @return  {Array}

 */
let getattachments = async function getattachments(cuerpo)
{

    var emlCorreo = new EmlParser(cuerpo)
  
    var result = await emlCorreo.parseEml();
  
      var dataAdjunto = [];
  
      var  datos = result.attachments
      
      for(var i = 0; i < datos.length; i++){
  
        var nameAdjunto = datos[i].filename;
        var base64 =  datos[i].content;
  
        var jsson = {
          nombre:nameAdjunto,
          bytes:base64
        }
  
        dataAdjunto.push(jsson);
      }
    return dataAdjunto
}


/**

 * guarda el token y el usuario en la base de datos

 * @param  {string}

 * @return  {Array}

 */
let GuardarToken = async function GuardarToken(usuarioGoogle,token,usuario)
{

    let ini = false;
  
    var dabaBase = await conexion();

    if (dabaBase == true)
    {
  
      const result = await sql.query(`UPDATE GmailAccounts SET token='${token}',usuario='${usuario}' WHERE usuarioGoogle='${usuarioGoogle}';`)
      //console.log(result.rowsAffected)
  
      if (result.rowsAffected[0]==1){
  
          console.log('se actualizo: '+usuarioGoogle)
          ini = true;
          sql.close()
          return ini
          
  
      } else{
  
        //console.log('no se encontro el usuario')
        sql.close()
        return ("No se encontro usuario "+usuarioGoogle)
        
      }
  
    }
    else
    {
  
        console.log("error en actualizar")
        return ("error en actualizar")
  
    }
    
    
}



 
// Exportamos las funciones 
module.exports = {
    conexion,
    guardar,
    getDatos,
    borrar,
    saveDocumenType,
    getattachments,
    GuardarToken
}